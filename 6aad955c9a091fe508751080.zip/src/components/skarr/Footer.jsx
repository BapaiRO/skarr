const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from "react";
import { MessageCircle, Youtube, Twitter } from "lucide-react";

const LOGO_URL = "https://media.db.com/images/public/6aad955c9a091fe508751080/284d4b91e_skarr_logo.png";

export default function Footer() {
  return (
    <footer className="relative bg-background border-t border-secondary/20 pt-16 pb-24 overflow-hidden">
      {/* Massive CTA */}
      <div className="max-w-7xl mx-auto px-6 lg:px-10 mb-16">
        <div className="text-center">
          <p className="font-mono text-[10px] text-primary tracking-[0.3em] uppercase mb-4">
            // Final Transmission
          </p>
          <h2 className="font-heading font-extrabold text-5xl md:text-7xl lg:text-8xl tracking-tighter text-foreground leading-none">
            NO RETREAT.
            <br />
            <span className="text-primary text-shadow-glow">JOIN THE DISCORD.</span>
          </h2>
          <a
            href="https://www.discord.com"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center gap-2 px-8 py-4 bg-primary hover:bg-primary/90 text-primary-foreground font-heading font-bold tracking-[0.15em] uppercase text-sm transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            Enter the Barracks
          </a>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="max-w-7xl mx-auto px-6 lg:px-10 pt-8 border-t border-secondary/15">
        <div className="grid md:grid-cols-3 gap-10 mb-10">
          <div>
            <img src={LOGO_URL} alt="SKARR" className="h-8 mix-blend-screen mb-4" />
            <p className="text-sm text-foreground/50 leading-relaxed max-w-xs">
              A Roblox realism studio founded by Bap. We port legends and build new ones —
              gritty, immersive, unflinching.
            </p>
          </div>

          <div>
            <h4 className="font-mono text-[10px] text-primary tracking-widest uppercase mb-4">
              Navigate
            </h4>
            <ul className="space-y-2 font-mono text-xs">
              <li><a href="#games" className="text-foreground/50 hover:text-primary transition-colors uppercase tracking-widest">Armory</a></li>
              <li><a href="#blog" className="text-foreground/50 hover:text-primary transition-colors uppercase tracking-widest">Intel</a></li>
              <li><a href="#about" className="text-foreground/50 hover:text-primary transition-colors uppercase tracking-widest">Unit</a></li>
              <li><a href="#contact" className="text-foreground/50 hover:text-primary transition-colors uppercase tracking-widest">Enlist</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-mono text-[10px] text-primary tracking-widest uppercase mb-4">
              Comms
            </h4>
            <div className="flex gap-3">
              <a href="https://www.discord.com" target="_blank" rel="noopener noreferrer" className="w-10 h-10 flex items-center justify-center bg-card border border-secondary/20 hover:border-primary hover:text-primary text-foreground/50 transition-colors" aria-label="Discord">
                <MessageCircle className="w-5 h-5" />
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" className="w-10 h-10 flex items-center justify-center bg-card border border-secondary/20 hover:border-primary hover:text-primary text-foreground/50 transition-colors" aria-label="YouTube">
                <Youtube className="w-5 h-5" />
              </a>
              <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer" className="w-10 h-10 flex items-center justify-center bg-card border border-secondary/20 hover:border-primary hover:text-primary text-foreground/50 transition-colors" aria-label="Twitter">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-secondary/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-mono text-[10px] text-secondary/40 tracking-widest uppercase">
            © {new Date().getFullYear()} SKARR Studio. All rights reserved.
          </p>
          <p className="font-mono text-[10px] text-secondary/40 tracking-widest uppercase">
            Founded by Bap · Leave a mark
          </p>
        </div>
      </div>
    </footer>
  );
}