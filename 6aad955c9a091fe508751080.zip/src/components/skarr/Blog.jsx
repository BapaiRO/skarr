const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { ArrowRight, Lock } from "lucide-react";

const categoryColors = {
  Devblog: "text-primary",
  Progress: "text-green-400",
  Studio: "text-secondary",
  Intel: "text-red-400",
};

function BlogCard({ post }) {
  const catColor = categoryColors[post.category] || "text-primary";
  const formattedDate = post.date
    ? new Date(post.date).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "2-digit" }).toUpperCase()
    : "";

  return (
    <article className="group relative bg-card border border-secondary/20 hover:border-primary/40 overflow-hidden transition-colors">
      <div className="flex">
        {/* Left rail — stamp */}
        <div className="hidden sm:flex flex-col items-center justify-center w-16 border-r border-secondary/15 bg-background/50 py-6">
          <Lock className="w-4 h-4 text-secondary/40 mb-2" />
          <span className="font-mono text-[9px] text-secondary/40 tracking-widest uppercase rotate-180" style={{ writingMode: "vertical-rl" }}>
            Classified
          </span>
        </div>

        {/* Content */}
        <div className="flex-1 p-6 md:p-8">
          {/* Metadata bar */}
          <div className="flex flex-wrap items-center gap-3 mb-4 font-mono text-[10px] tracking-widest uppercase">
            <span className={catColor}>{post.category}</span>
            <span className="text-secondary/30">|</span>
            <span className="text-secondary/60">{formattedDate}</span>
            <span className="text-secondary/30">|</span>
            <span className="text-secondary/60">Auth: {post.author || "Bap"}</span>
          </div>

          {/* Redacted title — reveals on hover */}
          <div className="relative overflow-hidden mb-3">
            <h3 className="font-heading font-extrabold text-xl md:text-2xl text-foreground leading-tight">
              {post.title}
            </h3>
            <div className="absolute inset-0 bg-secondary/70 group-hover:translate-x-[101%] transition-transform duration-500 ease-out flex items-center px-4">
              <span className="font-mono text-xs text-background/80 tracking-widest uppercase">
                ████ Classi██ed — Hover to █eveal
              </span>
            </div>
          </div>

          <p className="text-sm text-foreground/60 leading-relaxed line-clamp-3">
            {post.excerpt}
          </p>

          {/* Signature line */}
          <div className="mt-5 pt-4 border-t border-secondary/10 flex items-center justify-between">
            <div className="font-mono text-[10px] text-secondary/40 tracking-widest">
              <p>AUTHORIZED BY: {post.author || "Bap"}</p>
              <p>REF: SKARR-{formattedDate.replace(/\s/g, "")}</p>
            </div>
            <span className="inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.2em] text-primary group-hover:gap-3 transition-all">
              Read Report
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </div>
    </article>
  );
}

export default function Blog() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.entities.BlogPost.list("-date", 20)
      .then(setPosts)
      .catch(() => setPosts([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section id="blog" className="relative py-24 bg-card/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        {/* Section header */}
        <div className="mb-12 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="font-mono text-[10px] text-primary tracking-[0.3em] uppercase">
                // Field Dispatch
              </span>
            </div>
            <h2 className="font-heading font-extrabold text-4xl md:text-5xl tracking-tight text-foreground">
              Intelligence Reports
            </h2>
          </div>
          <p className="font-mono text-xs text-secondary/60 max-w-xs">
            Development logs, progress reports, and stories from the studio floor.
          </p>
        </div>

        {/* Posts */}
        {loading ? (
          <div className="space-y-4">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-40 bg-card border border-secondary/10 animate-pulse" />
            ))}
          </div>
        ) : posts.length === 0 ? (
          <div className="py-20 text-center border border-dashed border-secondary/20">
            <p className="font-mono text-sm text-secondary/50 uppercase tracking-widest">
              No dispatches received
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map((p) => (
              <BlogCard key={p.id} post={p} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}