import React from "react";
import { Shield, Target, Skull, Users } from "lucide-react";

const team = [
  { name: "Bap", role: "Founder / Lead Dev", initial: "B", id: "SK-001" },
  { name: "Vex", role: "Environment Artist", initial: "V", id: "SK-002" },
  { name: "Rook", role: "Combat Systems Eng.", initial: "R", id: "SK-003" },
  { name: "Halo", role: "Animation / Rigging", initial: "H", id: "SK-004" },
];

const values = [
  {
    icon: Target,
    title: "Realism First",
    text: "We treat Roblox as a serious engine. Ballistics, lighting, and physics — tuned for immersion, not toys.",
  },
  {
    icon: Shield,
    title: "Respect the Source",
    text: "Every port honors what made the original great. We adapt, we don't dilute.",
  },
  {
    icon: Skull,
    title: "Gritty by Design",
    text: "Our name is a scar. Our games wear that — hard edges, hard choices, no soft landings.",
  },
];

export default function About() {
  return (
    <section id="about" className="relative py-24 bg-background">
      {/* Ambient glow */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          background:
            "radial-gradient(circle at 20% 50%, rgba(255,77,0,0.4) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(169,103,123,0.3) 0%, transparent 50%)",
        }}
      />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-10">
        {/* Story */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-24">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="font-mono text-[10px] text-primary tracking-[0.3em] uppercase">
                // The Scar
              </span>
            </div>
            <h2 className="font-heading font-extrabold text-4xl md:text-5xl tracking-tight text-foreground leading-tight">
              A studio forged from a founder's past.
            </h2>
            <div className="mt-6 space-y-4 text-foreground/70 leading-relaxed">
              <p>
                SKARR takes its name from{" "}
                <span className="text-primary font-semibold">scar</span> — a mark left
                behind, a wound that never quite healed. For founder{" "}
                <span className="text-foreground font-semibold">Bap</span>, it's a reminder
                of where he came from and what he survived to build.
              </p>
              <p>
                What started as one developer porting beloved shooters into Roblox has grown
                into a studio obsessed with one thing: making realistic combat games that
                don't feel like Roblox games. The engine is the canvas. The grit is the point.
              </p>
              <p className="font-mono text-sm text-secondary/70 border-l-2 border-primary/40 pl-4">
                We're a small unit. We move fast, we ship hard, and we leave a mark.
              </p>
            </div>
          </div>

          {/* Dossier card */}
          <div className="relative">
            <div className="relative aspect-[4/5] border border-secondary/30 bg-gradient-to-br from-card via-background to-black overflow-hidden scanlines">
              <div
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage:
                    "linear-gradient(rgba(255,77,0,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(255,77,0,0.4) 1px, transparent 1px)",
                  backgroundSize: "40px 40px",
                }}
              />
              <div
                className="absolute inset-0 opacity-40"
                style={{
                  background:
                    "radial-gradient(ellipse at 50% 60%, rgba(169,103,123,0.4) 0%, transparent 60%)",
                }}
              />
              {/* Dossier header */}
              <div className="absolute top-0 inset-x-0 p-5 border-b border-secondary/20 bg-background/50">
                <p className="font-mono text-[10px] text-secondary/60 tracking-widest uppercase">
                  Personnel File
                </p>
                <p className="font-mono text-[10px] text-primary tracking-widest mt-1">
                  ID: SK-001 · CLASS: FOUNDER
                </p>
              </div>
              {/* Quote */}
              <div className="absolute bottom-0 inset-x-0 p-6 bg-gradient-to-t from-background via-background/80 to-transparent">
                <p className="font-heading font-extrabold text-2xl text-foreground tracking-tight">
                  "Leave a mark."
                </p>
                <p className="font-mono text-[10px] tracking-[0.3em] uppercase text-primary mt-2">
                  — Bap, Founder
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Values */}
        <div className="grid md:grid-cols-3 gap-6 mb-24">
          {values.map((v) => (
            <div
              key={v.title}
              className="p-6 bg-card border border-secondary/20 hover:border-primary/40 transition-colors"
            >
              <v.icon className="w-7 h-7 text-primary mb-4" />
              <h3 className="font-heading font-bold text-lg text-foreground">{v.title}</h3>
              <p className="mt-2 text-sm text-foreground/60 leading-relaxed">{v.text}</p>
            </div>
          ))}
        </div>

        {/* Team roster */}
        <div>
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-3">
              <Users className="w-4 h-4 text-primary" />
              <span className="font-mono text-[10px] text-primary tracking-[0.3em] uppercase">
                // The Unit
              </span>
            </div>
            <h2 className="font-heading font-extrabold text-3xl md:text-4xl tracking-tight text-foreground">
              Personnel Roster
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((m) => (
              <div
                key={m.name}
                className="group p-6 bg-card border border-secondary/20 hover:border-primary/40 transition-colors text-center"
              >
                <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-primary/30 via-muted to-background flex items-center justify-center mb-4 border-2 border-secondary/30 group-hover:border-primary/60 transition-colors grayscale group-hover:grayscale-0">
                  <span className="font-heading font-extrabold text-3xl text-foreground">
                    {m.initial}
                  </span>
                </div>
                <h3 className="font-heading font-bold text-lg text-foreground">{m.name}</h3>
                <p className="mt-1 font-mono text-[10px] tracking-widest uppercase text-primary/80">
                  {m.role}
                </p>
                <p className="mt-2 font-mono text-[9px] tracking-widest text-secondary/40">
                  {m.id}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}