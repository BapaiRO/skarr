const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { ChevronUp, Crosshair } from "lucide-react";
import { Image } from "@/components/ui/image";

const LOGO_URL = "https://media.db.com/images/public/6aad955c9a091fe508751080/284d4b91e_skarr_logo.png";
const HERO_BG = "https://media.db.com/images/public/6aad955c9a091fe508751080/3e46d2e24_generated_image.png";

export default function Hero() {
  const [booted, setBooted] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setBooted(true), 2500);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const thermalOpacity = Math.min(scrollY / 600, 0.5);

  return (
    <section
      id="top"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background scanlines"
    >
      {/* Background image */}
      <div className="absolute inset-0">
        <Image
          src={HERO_BG}
          alt="Abandoned industrial war zone"
          fittingType="fill"
          className="w-full h-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/40 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background/50" />
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at center, transparent 15%, rgba(10,11,13,0.85) 100%)" }} />
      </div>

      {/* Thermal / heat-map scroll overlay */}
      <div
        className="absolute inset-0 pointer-events-none mix-blend-screen transition-opacity duration-300"
        style={{
          opacity: thermalOpacity,
          background:
            "linear-gradient(180deg, rgba(0,255,65,0.15) 0%, rgba(255,77,0,0.2) 50%, rgba(0,255,65,0.15) 100%)",
        }}
      />

      {/* Tactical grid */}
      <div
        className="absolute inset-0 opacity-[0.06] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,77,0,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,77,0,0.6) 1px, transparent 1px)",
          backgroundSize: "80px 80px",
        }}
      />

      {/* Warning stripes — top edge */}
      <div className="absolute top-0 inset-x-0 h-2 warning-stripes opacity-70 z-20" />

      {/* Scar gash — jagged diagonal incision */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none"
        preserveAspectRatio="none"
        viewBox="0 0 100 100"
      >
        <defs>
          <filter id="scarGlow">
            <feGaussianBlur stdDeviation="0.4" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <path
          d="M 0,42 L 12,40 L 22,46 L 34,38 L 44,44 L 54,36 L 64,42 L 74,34 L 86,40 L 100,36"
          stroke="rgba(255,77,0,0.95)"
          strokeWidth="0.4"
          fill="none"
          filter="url(#scarGlow)"
        />
        <path
          d="M 0,42.5 L 12,40.5 L 22,46.5 L 34,38.5 L 44,44.5 L 54,36.5 L 64,42.5 L 74,34.5 L 86,40.5 L 100,36.5"
          stroke="rgba(0,0,0,0.8)"
          strokeWidth="0.25"
          fill="none"
        />
      </svg>

      {/* HUD corner markers */}
      <div className="absolute top-6 left-6 font-mono text-[10px] text-secondary/50 tracking-widest hidden sm:block">
        <p>LAT 48.8566° N</p>
        <p>LON 02.3522° E</p>
      </div>
      <div className="absolute top-6 right-6 font-mono text-[10px] text-secondary/50 tracking-widest text-right hidden sm:block">
        <p>SECTOR: ALPHA</p>
        <p>STATUS: ACTIVE</p>
      </div>

      {/* Diagnostic boot overlay */}
      {!booted && (
        <div className="absolute bottom-24 left-6 z-30 font-mono text-xs text-primary/70 space-y-0.5 animate-flicker">
          <p>{"> SKARR_OS v2.6.1"}</p>
          <p>{"> LOADING COMBAT ASSETS..."}</p>
          <p>{"> CALIBRATING BALLISTICS..."}</p>
          <p className="text-primary">{"> SYSTEM ONLINE"}</p>
        </div>
      )}

      {/* Main content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center animate-slide-in">
        <div className="inline-flex items-center gap-2 px-3 py-1 mb-6 border border-primary/40 bg-primary/5">
          <Crosshair className="w-3 h-3 text-primary" />
          <span className="font-mono text-[10px] tracking-[0.3em] uppercase text-primary">
            Roblox Realism Studio
          </span>
        </div>

        <img
          src={LOGO_URL}
          alt="SKARR"
          className="mx-auto h-32 sm:h-40 md:h-48 w-auto mix-blend-screen mb-2"
        />

        <div className="flex items-center justify-center gap-3 mb-6">
          <span className="h-px w-10 bg-primary/50" />
          <p className="font-mono text-[11px] tracking-[0.4em] uppercase text-secondary">
            Founded by Bap
          </p>
          <span className="h-px w-10 bg-primary/50" />
        </div>

        <p className="max-w-2xl mx-auto text-lg md:text-xl text-foreground/80 leading-relaxed font-body">
          We port legends into the Roblox engine. From{" "}
          <span className="text-primary font-semibold">Team Fortress 2</span> to
          original realistic combat experiences — built gritty, played hard.
        </p>

        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#games"
            className="group relative px-8 py-3.5 bg-primary hover:bg-primary/90 text-primary-foreground font-heading font-bold tracking-[0.15em] uppercase text-sm transition-all hover:tracking-[0.2em]"
          >
            Commence Operation
          </a>
          <a
            href="#about"
            className="px-8 py-3.5 border border-secondary/40 hover:border-primary hover:text-primary text-foreground/80 font-heading font-bold tracking-[0.15em] uppercase text-sm transition-colors"
          >
            Studio Dossier
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-20 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1">
        <span className="font-mono text-[9px] tracking-[0.3em] uppercase text-secondary/50">
          Scroll to Engage
        </span>
        <ChevronUp className="w-4 h-4 text-primary/50 animate-bounce" />
      </div>
    </section>
  );
}