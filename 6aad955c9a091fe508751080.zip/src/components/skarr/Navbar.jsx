const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from "react";

const LOGO_URL = "https://media.db.com/images/public/6aad955c9a091fe508751080/284d4b91e_skarr_logo.png";

const links = [
  { label: "Armory", href: "#games", code: "01" },
  { label: "Intel", href: "#blog", code: "02" },
  { label: "Unit", href: "#about", code: "03" },
  { label: "Enlist", href: "#contact", code: "04" },
];

export default function Navbar() {
  return (
    <header className="fixed bottom-0 inset-x-0 z-50 bg-background/95 backdrop-blur-md border-t border-secondary/30">
      <div className="h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        <a href="#top" className="flex items-center shrink-0">
          <img src={LOGO_URL} alt="SKARR" className="h-7 mix-blend-screen" />
        </a>

        <ul className="hidden md:flex items-center gap-6">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.2em] text-secondary hover:text-primary transition-colors"
              >
                <span className="text-primary/50">[{l.code}]</span>
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <ul className="flex md:hidden items-center gap-3">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="font-mono text-[10px] uppercase tracking-widest text-secondary hover:text-primary transition-colors whitespace-nowrap"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <a
          href="#contact"
          className="hidden lg:inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-primary border border-primary/50 px-3 py-1.5 hover:bg-primary hover:text-primary-foreground transition-colors shrink-0"
        >
          Deploy
        </a>
      </nav>
    </header>
  );
}