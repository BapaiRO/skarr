import React from "react";
import { Send, Radio } from "lucide-react";

export default function Enlist() {
  const [submitted, setSubmitted] = React.useState(false);

  return (
    <section id="contact" className="relative py-24 bg-card/30 overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.05] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,77,0,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,77,0,0.6) 1px, transparent 1px)",
          backgroundSize: "100px 100px",
        }}
      />
      <div className="relative max-w-4xl mx-auto px-6 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Radio className="w-4 h-4 text-primary animate-pulse" />
          <span className="font-mono text-[10px] text-primary tracking-[0.3em] uppercase">
            // Enlist
          </span>
        </div>
        <h2 className="font-heading font-extrabold text-4xl md:text-5xl tracking-tight text-foreground">
          Ready to ship to the front?
        </h2>
        <p className="mt-5 max-w-xl mx-auto text-foreground/60 leading-relaxed">
          Join the SKARR ranks. Get dispatches on new ports, playtest invites, and early
          access to upcoming operations.
        </p>

        {submitted ? (
          <div className="mt-10 inline-flex items-center gap-2 px-6 py-4 border border-primary/40 bg-primary/10">
            <Send className="w-4 h-4 text-primary" />
            <p className="font-mono text-sm text-primary tracking-widest uppercase">
              Enlisted. Stand by for dispatch.
            </p>
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSubmitted(true);
            }}
            className="mt-10 flex flex-col sm:flex-row gap-3 max-w-lg mx-auto"
          >
            <input
              type="email"
              required
              placeholder="your@email.com"
              className="flex-1 px-4 py-3 bg-background border border-secondary/30 focus:border-primary text-foreground placeholder:text-secondary/40 font-mono text-sm outline-none transition-colors"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary hover:bg-primary/90 text-primary-foreground font-heading font-bold tracking-[0.15em] uppercase text-sm transition-colors"
            >
              <Send className="w-4 h-4" />
              Enlist
            </button>
          </form>
        )}

        <p className="mt-8 font-mono text-[10px] text-secondary/40 tracking-widest uppercase">
          No spam. Only dispatches from the front.
        </p>
      </div>
    </section>
  );
}