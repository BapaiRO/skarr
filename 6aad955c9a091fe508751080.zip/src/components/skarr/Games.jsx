const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { Crosshair, ExternalLink, ChevronDown } from "lucide-react";
import { Image } from "@/components/ui/image";

const statusStyles = {
  LIVE: { color: "text-green-400", border: "border-green-400/50", bg: "bg-green-400/10", dot: "bg-green-400" },
  "IN DEV": { color: "text-primary", border: "border-primary/50", bg: "bg-primary/10", dot: "bg-primary" },
  CLASSIFIED: { color: "text-red-400", border: "border-red-400/50", bg: "bg-red-400/10", dot: "bg-red-400" },
  CONCEPT: { color: "text-secondary", border: "border-secondary/50", bg: "bg-secondary/10", dot: "bg-secondary" },
};

function GameCard({ game, index }) {
  const [expanded, setExpanded] = useState(false);
  const s = statusStyles[game.status] || statusStyles["IN DEV"];

  return (
    <article
      className="group relative bg-card border border-secondary/20 hover:border-primary/50 overflow-hidden transition-colors"
      onMouseEnter={() => setExpanded(true)}
      onMouseLeave={() => setExpanded(false)}
    >
      {/* Coordinate marker */}
      <span className="absolute top-3 left-3 z-20 font-mono text-[10px] text-secondary/40 tracking-widest">
        [{String(index + 1).padStart(2, "0")}]
      </span>

      <div className="flex flex-col md:flex-row">
        {/* Image */}
        <div className="relative md:w-2/5 h-56 md:h-auto overflow-hidden">
          {game.image_url ? (
            <Image
              src={game.image_url}
              alt={game.title}
              fittingType="fill"
              className="w-full h-full object-cover grayscale-0 transition-all duration-500"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-muted to-background" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-card via-card/20 to-transparent md:bg-gradient-to-r" />
        </div>

        {/* Content */}
        <div className="relative flex-1 p-6 md:p-8 flex flex-col">
          {/* Status badge */}
          <div className="flex items-center gap-3 mb-4">
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 ${s.bg} ${s.border} ${s.color} font-mono text-[10px] font-bold tracking-widest uppercase`}>
              <span className={`w-1.5 h-1.5 rounded-full ${s.dot} animate-pulse`} />
              {game.status}
            </span>
            {game.tag && (
              <span className="font-mono text-[10px] text-secondary/60 tracking-widest uppercase">
                {game.tag}
              </span>
            )}
          </div>

          <h3 className="font-heading font-extrabold text-2xl md:text-3xl text-foreground leading-tight tracking-tight">
            {game.title}
          </h3>

          <p className="mt-3 text-sm md:text-base text-foreground/60 leading-relaxed">
            {game.description}
          </p>

          {/* Tactical overview — features (expand on hover) */}
          <div
            className="overflow-hidden transition-all duration-300"
            style={{ maxHeight: expanded && game.features?.length ? "200px" : "0px" }}
          >
            {game.features?.length > 0 && (
              <div className="mt-4 pt-4 border-t border-secondary/15">
                <p className="font-mono text-[10px] text-primary/70 tracking-widest uppercase mb-2">
                  // Tactical Overview
                </p>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {game.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-2 font-mono text-xs text-foreground/70">
                      <ChevronDown className="w-3 h-3 text-primary/50 rotate-[-90deg]" />
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Deploy button */}
          <a
            href={game.roblox_url || "https://www.roblox.com"}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex items-center gap-2 self-start font-mono text-xs uppercase tracking-[0.2em] text-primary hover:text-primary/80 border border-primary/40 hover:border-primary hover:bg-primary/10 px-4 py-2.5 transition-all"
          >
            <Crosshair className="w-3.5 h-3.5" />
            Deploy to {game.title.split(":")[0].split(" ")[0]}
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </article>
  );
}

export default function Games() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.entities.Game.list("order", 100)
      .then(setGames)
      .catch(() => setGames([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section id="games" className="relative py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        {/* Section header */}
        <div className="mb-12 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="font-mono text-[10px] text-primary tracking-[0.3em] uppercase">
                // Active Operations
              </span>
            </div>
            <h2 className="font-heading font-extrabold text-4xl md:text-5xl tracking-tight text-foreground">
              The Armory
            </h2>
          </div>
          <p className="font-mono text-xs text-secondary/60 max-w-xs">
            Every project is a campaign. Here's what SKARR is shipping to the front lines.
          </p>
        </div>

        {/* Games list */}
        {loading ? (
          <div className="space-y-4">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-64 bg-card border border-secondary/10 animate-pulse" />
            ))}
          </div>
        ) : games.length === 0 ? (
          <div className="py-20 text-center border border-dashed border-secondary/20">
            <p className="font-mono text-sm text-secondary/50 uppercase tracking-widest">
              No active operations
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {games.map((g, i) => (
              <GameCard key={g.id} game={g} index={i} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}